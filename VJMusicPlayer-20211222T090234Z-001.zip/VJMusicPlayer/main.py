import os
import time
import tkinter.messagebox
from tkinter import *  # importing tkinter library
from pygame import mixer  # importing mixer from pygame library
from mutagen.mp3 import MP3
from tkinter import filedialog
import threading

root = Tk()  # creates a blank GUI

statusbar = Label(root, text='Welcome to VJ', relief=SUNKEN, anchor=W)
statusbar.pack(side=BOTTOM, fill=X)

# Create the menubar
menubar = Menu(root)
root.config(menu=menubar)

# Create the submenu

subMenu = Menu(menubar, tearoff=0)

playlist = []

# playlist - contains the full path + filename
# playlistbox - contains just the filename
# Fullpath + filename is required to play the music inside playmusic load function

index = 0

def browsefile():
    global filepath
    filepath = filedialog.askopenfilename()
    add_to_playlist(filepath)

def add_to_playlist(filename):
    global index
    filename = os.path.basename(filename)
    playlistbox.insert(index, filename)
    playlist.insert(index, filepath)
    index += 1

menubar.add_cascade(label="File", menu=subMenu)
subMenu.add_command(label="Open", command=browsefile)
subMenu.add_command(label="Exit", command=root.destroy)


def about_us():
    tkinter.messagebox.showinfo('About VJ',
                                'This is a music player build using Python Tkinter by @JanhaviBhutki & @VarijakshKatti')


subMenu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="Help", menu=subMenu)
subMenu.add_command(label="About Us", command=about_us)

mixer.init()  # initializing mixer

#root.geometry("500x500")  # width x Height
root.title("VJ Music player")  # title of gui
root.iconbitmap("Images/music_note_Eeb_icon.ico")  # icon for gui

# Root Window - StatusBar, LeftFrame, RightFrame
# LeftFrame - The listbox (playlist), leftbotframe
# RightFrame - TopFrame,MiddleFrame and the BottomFrame

leftframe = Frame(root)
leftframe.pack(side=LEFT,padx=30)

playlistbox = Listbox(leftframe)
playlistbox.pack()

leftbotframe = Frame(leftframe)
leftbotframe.pack()

addbtn = Button(leftbotframe, text = '+ add', command = browsefile)
addbtn.grid(row=0,column=0)

delbtn = Button(leftbotframe, text = '- delete')
delbtn.grid(row=0,column=1)

rightframe = Frame(root)
rightframe.pack()

topframe = Frame(rightframe)
topframe.pack()

lengthlabel = Label(topframe, text='Total length : --:--')
lengthlabel.pack()

currenttimelabel = Label(topframe, text='Current Time - 00:00', relief=GROOVE)
currenttimelabel.pack(pady=10)



def showDetails(play_song):

    file_data = os.path.splitext(play_song)

    if file_data[1] == '.mp3':
        audio = MP3(play_song)
        total_length = audio.info.length
    else:
        a = mixer.Sound(play_song)
        total_length = a.get_length()

    # div - total_length/60, mod - total_length % 60
    mins, sec = divmod(total_length, 60)
    mins = round(mins)
    sec = round(sec)
    timeformat = '{:02d}:{:02d}'.format(mins, sec)
    lengthlabel['text'] = "Total Length" + ' - ' + timeformat

    t1 = threading.Thread(target=start_count, args=(total_length,))
    t1.start()

def start_count(t):
    global paused
    # mixer.music.get_busy(): - Returns FALSE when we press the stop button (music stop playing)
    # Continue - Ignores all of the statements below it. We check if music is paused or not.
    x = 0
    while x <= t and mixer.music.get_busy():
        if paused:
            continue
        else:
            mins, secs = divmod(x, 60)
            mins = round(mins)
            secs = round(secs)
            timeformat = '{:02d}:{:02d}'.format(mins, secs)
            currenttimelabel['text'] = "Current Time" + ' - ' + timeformat
            time.sleep(1)
            x += 1

def playmusic():
    global paused
    if paused:
        mixer.music.unpause()
        statusbar['text'] = "Music Resumed"
        paused=FALSE
    else:
        try:
            stopmusic()
            time.sleep(1)
            selected_song = playlistbox.curselection()
            selected_song = int(selected_song[0])
            play_it = playlist[selected_song]
            mixer.music.load(play_it)
            mixer.music.play()
            statusbar['text'] = "Playing Music" + " " + os.path.basename(
                play_it)  # so that only the file name will be displayed in the status bar
            showDetails(play_it)
        except:
            tkinter.messagebox.showerror('File Not Found',
                                         'VJ was unable to find any file. Select a file and try again.')

def stopmusic():
    mixer.music.stop()
    statusbar['text'] = "Music Stopped"

paused=FALSE

def pausemusic():
    global paused
    paused = TRUE
    mixer.music.pause()
    statusbar['text'] = "Music paused"



def rewindmusic():
    playmusic()
    statusbar['text'] = "Playing from the start"


def setvol(Val):
    volume = int(Val) / 100
    mixer.music.set_volume(volume)


# set_volume of mixer takes value only from 0 to 1. Example - 0, 0.1,0.55,0.54.0.99,1

muted = False


def mutemusic():
    global muted
    if muted:  # Unmute the music
        mixer.music.set_volume(0.7)
        volumeBtn.configure(image=volumePhoto)
        scale.set(70)
        muted = FALSE
    else:  # mute the music
        mixer.music.set_volume(0)
        volumeBtn.configure(image=mutePhoto)
        scale.set(0)
        muted = TRUE


middleframe = Frame(rightframe)
middleframe.pack(padx=30, pady=30)

playphoto = PhotoImage(file='Images/play-button.png')
playbtn = Button(middleframe, image=playphoto, command=playmusic)  # inserting button for playing in GUI
playbtn.grid(row=0, column=0, padx=10)

stopPhoto = PhotoImage(file='Images/stop-button.png')
stopBtn = Button(middleframe, image=stopPhoto, command=stopmusic)
stopBtn.grid(row=0, column=1, padx=10)

pausePhoto = PhotoImage(file='Images/pause-button.png')
pauseBtn = Button(middleframe, image=pausePhoto, command=pausemusic)
pauseBtn.grid(row=0, column=2, padx=10)

# Bottom Frame for volume, rewind, mute etc.

bottomframe = Frame(rightframe)
bottomframe.pack(padx=10, pady=10)

rewindPhoto = PhotoImage(file='Images/rewind-button.png')
rewindBtn = Button(bottomframe, image=rewindPhoto, command=rewindmusic)
rewindBtn.grid(row=0, column=0)

mutePhoto = PhotoImage(file='Images/mute.png')
volumePhoto = PhotoImage(file='Images/sound.png')
volumeBtn = Button(bottomframe, image=volumePhoto, command=mutemusic)
volumeBtn.grid(row=0, column=1)

scale = Scale(bottomframe, from_=0, to=100, orient=HORIZONTAL, command=setvol)
scale.set(70)  # implement the default value of scale when music player starts
mixer.music.set_volume(0.35)
scale.grid(row=0, column=2, pady=15, padx=30)


def on_closing():
    stopmusic()
    root.destroy()

root.protocol('WM_DELETE_WINDOW',on_closing)
root.mainloop()
